
package aula0106.exercici01;



import java.util.Scanner;

public class calculadora {
    private Operacoes operacoes;
    private Scanner scanner;
    
    public calculadora() {
        operacoes = new Operacoes();
        scanner = new Scanner(System.in);
    }
    
    public int somar(int a, int b) {
        return operacoes.soma(a, b);
    }
    
    public int subtrair(int a, int b) {
        return operacoes.subtracao(a, b);
    }
    
    public int multiplicar(int a, int b) {
        return operacoes.multiplicacao(a, b);
    }
    
    public double divisao(int a, int b) {
        return operacoes.divisao(a, b);
    }
    
    public int quadrado(int a) {
        return operacoes.quadrado(a);
    }
    
    public void executarCalculadora() {
        int a, b;
        
        System.out.print("Digite o primeiro numero: ");
        a = scanner.nextInt();
        
        System.out.print("Digite o segundo numero: ");
        b = scanner.nextInt();
        
        System.out.println("Soma: " + somar(a, b));
        System.out.println("Subtracao: " + subtrair(a, b));
        System.out.println("Multiplicacao: " + multiplicar(a, b));
        
        double resultadoDivisao = divisao(a, b);
        if (Double.isInfinite(resultadoDivisao)) {
            System.out.println("Erro: Divisao por zero.");
        } else {
            System.out.println("Divisao: " + resultadoDivisao);
        }
        
         int quadrado1 = operacoes.quadrado(a);
        int quadrado2 = operacoes.quadrado(b);

        System.out.println("Quadrado do primeiro numero: " + quadrado1);
        System.out.println("Quadrado do segundo numero: " + quadrado2);

        System.out.print("Digite o valor do lado do quadrado: ");
        int lado = scanner.nextInt();

        int areaQuadrado = operacoes.calcularAreaQuadrado(lado);
        System.out.println("area do quadrado: " + areaQuadrado);
    }
    
    public static void main(String[] args) {
        calculadora calculadora = new calculadora();
        calculadora.executarCalculadora();
    }
}

