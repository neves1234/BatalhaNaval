
package aula15exercicio04;


public class Pessoa {
    public String eMail;
    public String nome;
    public String telefone;
    public String endereco;
    
    public Pessoa(String nome, String eMail, String telefone, String endereco){
        this.nome = nome;
        this.eMail = eMail;
        this.telefone = telefone;
        this.endereco = endereco;
    }
    public String obterDados(){
        String retorno = "nome: "+nome;
        retorno+="znemail: "+eMail;
        retorno+="\ntelefone: "+telefone;
        retorno+="\nendereco: "+endereco;
        return retorno;
    }
}
