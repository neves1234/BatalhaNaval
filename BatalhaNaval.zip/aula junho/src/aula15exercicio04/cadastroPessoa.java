package aula15exercicio04;

import java.util.Scanner;

public class cadastroPessoa {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        Pessoa lista[] = new Pessoa[10];
        char opc;
        int contPessoa = 0;
        do {
            System.out.println("c - cadastrar pessoa");
            System.out.println("i - listar pessoa");
            System.out.println("s - sair");
            opc = ler.next().toLowerCase().charAt(0);
            switch (opc) {
                case 'c' -> {
                    System.out.println("cadastro de pessoas");
                    System.out.print("nome: ");
                    String nome = ler.next();
                    System.out.print("E-mail: ");
                    String eMail = ler.next();
                    System.out.print("Telefone: ");
                    String telefone = ler.next();
                    System.out.print("Endereco: ");
                    String endereco = ler.next();
                    lista[contPessoa] = new Pessoa(nome, eMail, telefone, endereco);
                    contPessoa++;

                }
            }
        }while();
    }
}
