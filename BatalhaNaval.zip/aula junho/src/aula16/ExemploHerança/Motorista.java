package aula16.ExemploHerança;


public class Motorista extends Funcionario{
    private String CNH;

    public String getCNH() {
        return CNH;
    }

    public void setCNH(String CNH) {
        this.CNH = CNH;
    }
    
}
