package aula.junho;



public class Pessoa {
    public String nome;
    public String sobrenome;
    public String mail;
    public int codigo;
    
    public String obterNomeCompleto(){
        return nome+ " "+sobrenome;
    }
    
    public String obterDadosPessoa(){
    String retorno = "Nome: "+nome+" "+sobrenome;
    retorno+="\nE-mail: "+mail;
    retorno += "\nCodigo: "+codigo;
    return  retorno;
    }
                                                        
                                                        
}
