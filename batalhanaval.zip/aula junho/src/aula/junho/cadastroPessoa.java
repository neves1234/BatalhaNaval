
package aula.junho;

import java.util.Scanner;

public class cadastroPessoa {
   public static void main(String[] args){
       Scanner ler = new Scanner(System.in);
       
       Pessoa pessoaUm = new Pessoa();
       pessoaUm.codigo = 10;
       pessoaUm.nome = "Ana";
       pessoaUm.sobrenome = "Silva";
       pessoaUm.mail = "ana@gmail.com";
       
       System.out.println(pessoaUm.obterNomeCompleto());
       System.out.println(pessoaUm.obterDadosPessoa());

       Pessoa pessoaDois = new Pessoa();
       
       System.out.println("digite o codigo: ");
       pessoaDois.codigo = ler.nextInt();
       System.out.println("digite o nome: ");
       pessoaDois.nome = ler.next();
       System.out.println("digite o sobrenome: ");
       pessoaDois.sobrenome = ler.next();
       System.out.println("digite o email: ");
       pessoaDois.mail = ler.next();
       
       System.out.println(pessoaDois.obterDadosPessoa());
   } 
}
