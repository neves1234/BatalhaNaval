
package aula0106.exercici01;

public class Operacoes {
    public int soma(int a, int b){
        return a + b;
    }
        
      public int subtracao(int a, int b) {
        return a - b;
    }
    
    public int multiplicacao(int a, int b ){
        return a * b;
    }
    public double divisao(int a, int b){
        if( b != 0 ){
            return a / b;
        } else {
             System.out.println("Erro: Divisão por zero.");
            return Double.POSITIVE_INFINITY;
        }
    }
    
    public int quadrado(int a){
        return a * a; 
    }
    
    public int calcularAreaQuadrado(int lado) {
        return quadrado(lado);
    }
    
}

