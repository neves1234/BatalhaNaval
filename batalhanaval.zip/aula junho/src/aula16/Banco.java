package aula16;

public class Banco {

    public static void main(String[] args) {
        Conta c1 = new Conta();
        Conta c2 = new Conta();

        c1.setTitular("jonas");
        c1.setIdentificador("A123");
        c1.depositar(100);
        System.out.println(c1.getTitular());
        System.out.println(c1.getIdentificador());
        System.out.printf("Seu saldo é de %.2f\n", c1.getSaldo());
    }
}
