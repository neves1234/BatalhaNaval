package aula16;


public class Conta {
   
    private String titular;
    private String identificador;
    private float saldo;
    
    public String getTitular(){
        return titular;
    }
    
    public void setTitular(String valor){
        titular = valor;
    }
    public String getIdentificador(){
        return identificador;
    }
    
    public void setIdentificador(String valor){
        identificador = valor;
    }
    
    public void depositar(float valor){
        saldo+=valor;
    }
    
    public boolean sacar(float valor){
        if (valor<=saldo){
            saldo-=valor;
            return true;
        }
        return false;
    }

    public float getSaldo(){
        return saldo;
    }
}
