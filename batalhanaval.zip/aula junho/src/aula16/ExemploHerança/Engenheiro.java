package aula16.ExemploHerança;

public class Engenheiro extends Funcionario {
    private String Crea;

    public String getCrea() {
        return Crea;
    }

    public void setCrea(String Crea) {
        this.Crea = Crea;
    }

    
}
