
package aula16.ExemploHerança;

public class teste {
    public static void main(String[]args){
        Motorista m1 = new Motorista();
        m1.setNome("Joao");
        m1.setSobrenome("Silva");
        m1.setMail("joao@gmail.com");
        m1.setCNH("1122334455");
        
        Engenheiro e1 = new Engenheiro();
        e1.setNome("Celso");
        e1.setSobrenome("fleck");
        e1.setMail("celso@gmail.com");
        e1.setCrea("1122334455");
        
        
        System.out.println("Motorista: "+m1.getNome()+" "+m1.getSobrenome()+" "+m1.getMail()+" "+m1.getCNH());
        System.out.println("Engenheiro: "+e1.getNome()+" "+e1.getSobrenome()+" "+e1.getMail()+" "+e1.getCrea());

    }
        
}
